<?php
$servername = "127.0.0.1:3306";
$username_id = "u496524825_mydata";
$password = "Sarita@1998";
$dbname = "u496524825_mydata";

// Create connection
$conn = new mysqli($servername, $username_id, $password, $dbname);

?>
