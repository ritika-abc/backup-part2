<?php
include "include/header.php";

include "include/contact.php";
?>

<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d31269.895531847582!2d79.38601690972753!3d11.570706272335379!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1s429%20Mudhanai%20Road%20Arasazuhi%20Satha%20Mangalam%20Post%20Virudhachallam%2C%20Cuddalore%2C%20Tamil%20Nadu%20606003%20-%20India!5e0!3m2!1sen!2sin!4v1711634354638!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
<?php

include "include/footer.php";

?>
    

