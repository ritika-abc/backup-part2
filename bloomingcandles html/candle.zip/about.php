<?php
include "include/header.php";
include "include/about.php";
include "include/why.php";
include "include/contact.php";
include "include/footer.php";

?>
    

