<?php
 include "include/header.php";
  include "include/about.php";
  include "include/service.php";
  include "include/feature.php";
  include "include/quote.php";
  include "include/footer.php";

?>

 


