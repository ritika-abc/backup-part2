<?php
 include "include/header.php";
  include "include/product.php";

  include "include/quote.php";
  include "include/footer.php";

?>

 


